
---

# Remote Workers Mental Health Analysis

## Project Overview

This project analyzes the mental health and productivity of remote employees using workplace survey data. The dataset contained demographic, job-related, and lifestyle attributes such as burnout, sleep, and work-life balance.

To focus the analysis:

* Removed the Name column to protect privacy.
* Applied a report-level filter (Work\_Mode = Remote).
* Rounded numerical fields (Experience\_Years, Hours\_Worked\_Per\_Week) for consistency.
* Created categorical labels:

  * Experience\_Years → Novice, Intermediate, Advanced, Expert.
  * Burnout\_Score → Low, Moderate, High, Extreme.

## Key Steps in Power BI

* Data Cleaning & Transformation

  * Removed unused/sensitive fields.
  * Rounded numerical values for readability.
  * Categorized burnout levels and experience years.

* Visualization

  * Burnout by Experience/Job Role: Clustered bar chart.
  * Sleep & Exercise vs Productivity: Scatterplots and trendlines.
  * Work-life Balance & Setup Satisfaction by Burnout: Stacked column chart.
  * Impact of Therapist Access & Communication: Key Influencers visual.

## Skills Demonstrated

* Power Query transformations
* Data cleaning & rounding logic
* Categorical labeling for analysis
* Dashboard storytelling in Power BI

## Impact

The dashboard provides insights into mental health risks and productivity trends among remote workers, helping HR teams and leadership to:

* Identify burnout patterns across different experience levels.
* See how workload, sleep, and exercise affect performance.
* Evaluate the role of therapist access, communication, and work-life balance in well-being.

---

